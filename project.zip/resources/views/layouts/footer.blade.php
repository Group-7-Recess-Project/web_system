<footer class="footer">
        <div class="copyright">
            &copy; {{ now()->year }} {{ __('CoCaRS Ug') }}
        </div>
</footer>
