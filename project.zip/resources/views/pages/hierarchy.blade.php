@extends('layouts.app', ['page' => __('User Profile'), 'pageSlug' => 'profile'])
@section('content')
<div class="row">
    <div class="col-md-12">
      <div class="card ">
        <div class="card-header">
          <h1 class="card-title"> Hierachical Graph</h1>
        </div>
        <div class="card-body">
          <div class="table-responsiv">
        </div>
    </div>
    </div>
        @endsection
