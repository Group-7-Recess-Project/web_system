<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-12">
      <div class="card ">
        <div class="card-header">
          <h1 class="card-title"> Hierachical Graph</h1>
        </div>
        <div class="card-body">
          <div class="table-responsiv">
        </div>
    </div>
    </div>
        <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', ['page' => __('User Profile'), 'pageSlug' => 'profile'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/code-lord/Desktop/pkproject/resources/views/pages/hierarchy.blade.php ENDPATH**/ ?>