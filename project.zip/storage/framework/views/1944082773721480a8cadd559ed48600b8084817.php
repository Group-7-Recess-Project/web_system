<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>CoCaRS | Patients</title>
  </head>
  <body>
Patients view
  </body>
</html>
<?php /**PATH /home/code-lord/Desktop/pkproject/resources/views/patients.blade.php ENDPATH**/ ?>