<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-12">
      <div class="card">
        <div class="card-header">
          <h1 class="title">At a glance</h1>
        </div>
        <div class="card-body all-icons">
          <div class="row">
            <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
              <div class="font-icon-detail" style="border: solid #525f7f;">
                
                <a href="<?php echo e(route('patients')); ?>">
                  
                  <h3>Cases</h3>
                  <hr>
                <h4><?php echo e(($total['patients'])); ?></h4>
               
              </a>
              </div>
            </div>
            <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
              <div class="font-icon-detail" style="border: solid #525f7f;">
                
                <a href="<?php echo e(route('officers')); ?>">
                 
                <h3>Officers</h3>
                <hr>
                <h4><?php echo e($total['officers']); ?></h4>
                
              </a>
              </div>
            </div>
            <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
              <div class="font-icon-detail" style="border: solid #525f7f;">
                
                <a href ="<?php echo e(route('hospitals')); ?>">
                 
                <h3>Hospitals</h3>
                <hr>
                <h4><?php echo e($total['hospitals']); ?></h4>
                
              </a>
              </div>
            </div>
            <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
              <div class="font-icon-detail" style="border: solid #525f7f;">
                <a href ="">
                
               
                <h3>Promotions</h3>
                <hr>
                <h4><?php echo e($total['promotions']); ?></h4>
            
              </a>
              </div>
            </div>
            <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
              <div class="font-icon-detail" style="border: solid #525f7f;">
                
               <a href =<?php echo e('#'); ?> style=":hover{color: blue;}">
                <h3 class="mb-0 mt-0">Balance</h3>
                <hr>
                <h4 class="mb-0 mt-0">UGX<br><?php echo e((number_format($total['donations']->total))); ?></h4>
                  
              </a>
              </div>
            </div>
            <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
                <div class="font-icon-detail" style="border: solid #525f7f;">
                  
                  <a href="<?php echo e(route('payments')); ?>">
                  
                    <h3>Payments</h3>
                    <hr>
                  <h4><?php echo e($total['payments']); ?></h4>
                
                </a>
                </div>
              </div>
        </div>
    </div>
</div>
<div class="row">
    <div class="col-md-12">
      <div class="card ">
        <div class="card-header">
          <h1 class="card-title"> Pending Cases</h1>
        </div>
        <div class="card-body">
          <div class="table-responsiv">
            <thead class=" text-primary">
              <tr>
                <th>
                  
                </th>
                <th>
                  
                </th>
              </tr>
            </thead>
            <tbody>
               


              <tr>
                <td>
                  
                </td>
                <td>
                    
                </td>
              </tr>
              
            </tbody>
        </div>
    </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', ['pageSlug' => 'dashboard'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/code-lord/Desktop/web_interface/resources/views/dashboard.blade.php ENDPATH**/ ?>