  
    <!-- Chart's container -->
    <?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
          <div class="card ">
            <div class="card-header">
              <h1 class="card-title"> Donations vs Donors graph  </h1>
            </div>
            <div class="card-body">
              <div class="table">

    <div id="chart" style="height: 400px; background: rgba(231, 240, 233, 0.212);"></div>
    <!-- Charting library -->
    <script src="https://unpkg.com/chart.js@2.9.3/dist/Chart.min.js"></script>
    <!-- Chartisan -->
    <script src="https://unpkg.com/@chartisan/chartjs@^2.1.0/dist/chartisan_chartjs.umd.js"></script>
    <!-- Your application script -->
    <script>
      const chart = new Chartisan({
        el: '#chart',
        url: "<?php echo route('charts.'.'donations'); ?>",
        hooks: new ChartisanHooks()
            .beginAtZero()
            .colors()
            .title("A graph of Donors Vs Amount")
            .responsive()
            .datasets([{type:"bar",
            backgroundColor: "blue",
            hoverBackgroundColor: "white",
            minBarLength:10,
            barPercentage: 1
        }])



      });

    </script>
    </div>
</div>
</div>
</div>
    <?php $__env->stopSection(); ?>
  


<?php echo $__env->make('layouts.app', ['class' => 'login-page', 'contentClass' => 'login-page'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/code-lord/Desktop/laravel_presentable/resources/views/charts/donations_chart.blade.php ENDPATH**/ ?>