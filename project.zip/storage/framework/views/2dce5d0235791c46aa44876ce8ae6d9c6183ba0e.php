<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header">
        <h1 class="title"><?php echo e(__('Register Hospital')); ?></h1>
    </div>
    <form method="post" action="<?php echo e(route('registerHospital')); ?>" autocomplete="off">
        <div class="card-body">
            <?php echo csrf_field(); ?>
            <?php echo $__env->make('alerts.success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <div class="form-group">
                <label><?php echo e(__('Hospital Name')); ?></label>
                <input type="text" name="hospital_name" class="form-control" placeholder="<?php echo e(__('Busesa Hospital')); ?>" value="" required>

            </div>

            <div class="form-group">
                <label><?php echo e(__('Hospital Category')); ?></label>
                <input type="text" name="hospital_category" class="form-control" placeholder="<?php echo e(__('General')); ?>" value="" required>

            </div>
            <div class="form-group">
                <label><?php echo e(__('District')); ?></label>
                <input type="text" name="district" class="form-control" placeholder="<?php echo e(__('Kampala')); ?>" value="" required>
            </div>
        </div>
        <div class="card-footer">
            <button type="submit" class="btn btn-fill btn-primary"><?php echo e(__('Register')); ?></button>
        </div>
    </form>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', ['pageSlug' => 'dashboard'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/code-lord/Desktop/laravel_presentable/resources/views/register/hospital.blade.php ENDPATH**/ ?>