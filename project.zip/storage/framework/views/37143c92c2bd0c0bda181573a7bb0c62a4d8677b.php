<footer class="footer">
        <div class="copyright">
            &copy; <?php echo e(now()->year); ?> <?php echo e(__('CoCaRS Ug')); ?>

        </div>
</footer>
<?php /**PATH /home/code-lord/Desktop/G-7-Recess-Project/web_system/resources/views/layouts/footer.blade.php ENDPATH**/ ?>