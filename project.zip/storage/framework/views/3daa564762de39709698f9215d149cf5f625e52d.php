<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header">
        <h1 class="title"><?php echo e(__('Register Health Officer')); ?></h1>
    </div>
    <form method="post" action="<?php echo e(route('registerOfficer')); ?>" autocomplete="off">
        <div class="card-body">
            <?php echo csrf_field(); ?>
            <?php echo $__env->make('alerts.success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <div class="form-group">
                <label><?php echo e(__('Officer Name')); ?></label>
                <input type="text" name="officer_name" class="form-control" placeholder="<?php echo e(__('Officer Name')); ?>" value="" required>

            </div>

            <div class="form-group">
                <label><?php echo e(__('Officer Username')); ?></label>
                <input type="text" name="username" class="form-control" placeholder="<?php echo e(__('username.')); ?>" value="" required>

            </div>
            <div class="form-group">
                <label><?php echo e(__('Officer Contact')); ?></label>
                <input type="text" name="email" class="form-control" placeholder="<?php echo e(__('example@here.com')); ?>" value="" required>
            </div>
        </div>
        <div class="card-footer">
            <button type="submit" class="btn btn-fill btn-primary"><?php echo e(__('Register')); ?></button>
        </div>
    </form>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', ['pageSlug' => 'dashboard'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/code-lord/Desktop/laravel_presentable/resources/views/register/officer.blade.php ENDPATH**/ ?>