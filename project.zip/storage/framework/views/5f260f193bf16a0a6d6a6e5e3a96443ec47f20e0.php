<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH /home/code-lord/Desktop/pkproject/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/button.blade.php ENDPATH**/ ?>