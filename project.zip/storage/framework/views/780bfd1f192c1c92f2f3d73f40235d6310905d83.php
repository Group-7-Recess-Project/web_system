<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header">
        <h1 class="title"><?php echo e(__('Register Hospital')); ?></h1>
    </div>
    <form method="post" action="<?php echo e(route('registerHospital')); ?>" autocomplete="off">
        <div class="card-body">
            <?php echo csrf_field(); ?>
            <?php echo $__env->make('alerts.success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <div class="form-group">
                <label><?php echo e(__('Hospital Name')); ?></label>
                <input type="text" name="hospital_name" class="form-control" placeholder="<?php echo e(__('Busesa Hospital')); ?>" value="" required>

            </div>

            <div class="form-group">
                <label><?php echo e(__('Hospital Category')); ?></label>
                
            <select name="hospital_category" class="form-control" style="background-color: #525f7f;">
                <option value="General">General Hospital</option>
                <option value="Regional">Regional Referral Hospital</option>
                <option value="National">National Referral Hospital</option>
            </select>
            </div>
            <div class="form-group">
                <label><?php echo e(__('District')); ?></label>
                
                <Select name="district" class="form-control" style="background-color: #525f7f;">
                    <option value="Kampala">Kampala</option>
                    <option value="Iganga">Iganga</option>
                    <option value="Mbarara">Mbarara/option>
                    <option value="Lyantonde">Lyantonde</option>
                    <option value="Masaka">Masaka</option>
                    <option value="Rakai">Rakai/option>
                    <option value="Kyotera">Kyotera</option>
                    <option value="Jinja">Jinja</option>
                    <option value="Kiruhura">Kiruhura</option>
                    <option value="Fortportal">Fortportal</option>
                    <option value="Hoima">Hoima</option>
                    <option value="OTHER">OTHER(SPECIFY)</option>
                </Select>
            </div>
        </div>
        <div class="card-footer">
            <button type="submit" class="btn btn-fill btn-primary"><?php echo e(__('Register')); ?></button>
        </div>
    </form>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', ['pageSlug' => 'dashboard'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/code-lord/Desktop/web_interface/resources/views/register/hospital.blade.php ENDPATH**/ ?>