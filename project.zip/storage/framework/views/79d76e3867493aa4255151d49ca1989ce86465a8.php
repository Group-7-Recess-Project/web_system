<footer class="footer">
        <div class="copyright">
            &copy; <?php echo e(now()->year); ?> <?php echo e(__('CoCaRS Ug')); ?>

        </div>
</footer>
<?php /**PATH /home/code-lord/Desktop/web_interface/resources/views/layouts/footer.blade.php ENDPATH**/ ?>