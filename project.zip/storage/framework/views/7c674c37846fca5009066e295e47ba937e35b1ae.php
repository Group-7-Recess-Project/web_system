
 <style>
    .sidebar-wrapper{
        background-color:  #525f7f !important;
        left:0;
    }
</style>

<div class="sidebar ">
    <div class="sidebar-wrapper">
        <div class="logo">
            <h3>
            <a href="#" class="simple-text logo-normal"><?php echo e(__(Auth::user()->name)); ?></a>
        </h3>

        </div>

        <ul class="nav">

             <li>
                <a href="<?php echo e(route('home')); ?>">
                    <i class="tim-icons icon-chart-pie-36"></i>
                    <p><?php echo e(__('Dashboard')); ?></p>
                </a>
            </li>
            <?php if(Auth::user()->job_role=='admin'): ?>
            <li>
                <a data-toggle="collapse" href="#register" aria-expanded="false">
                    <i class="tim-icons icon-pencil" ></i>
                    <span class="nav-link-text" ><?php echo e(__('Register')); ?></span>
                    <b class="caret mt-1"></b>
                </a>

                <div class="collapse" id="register">
                    <ul class="nav pl-4">

                        <li>
                            <a href="<?php echo e(route('registerDonation')); ?>">
                                <i class="tim-icons icon-coins"></i>
                                <p><?php echo e(__('Donnation')); ?></p>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo e(route('registerOfficer')); ?>">
                                <i class="tim-icons icon-single-02"></i>
                                <p><?php echo e(__('Health Officer')); ?></p>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo e(route('registerHospital')); ?>">
                                <i class="tim-icons icon-bank"></i>
                                <p><?php echo e(__('Hospital')); ?></p>
                            </a>
                        </li>

                    </ul>
                </div>
            </li>
            <?php endif; ?>

<li>
    <a data-toggle="collapse" href="#graphs" aria-expanded="false">
        <i class="tim-icons icon-chart-bar-32" ></i>
        <span class="nav-link-text" ><?php echo e(__('Graphs')); ?></span>
        <b class="caret mt-1"></b>
    </a>

    <div class="collapse" id="graphs">
        <ul class="nav pl-4">
            <li>
                <a href="<?php echo e(route('charts')); ?>">
                    <i class="tim-icons icon-single-02"></i>
                    <p><?php echo e(__('Donations Graphs')); ?></p>
                </a>
            </li>
            <li>
                <a href="<?php echo e(route('hierarchy')); ?>">
                    <i class="tim-icons icon-coins"></i>
                    <p><?php echo e(__('Hierarchy')); ?></p>
                </a>
            </li>
            <li>
                <a href="<?php echo e(route('enrollment')); ?>">
                    <i class="tim-icons icon-single-02"></i>
                    <p><?php echo e(__('Enrollment Change')); ?></p>
                </a>
            </li>

            

        </ul>
    </div>
</li>


            <li>
                <a href="<?php echo e(route('pages.icons')); ?>">
                    <i class="tim-icons icon-atom"></i>
                    <p><?php echo e(__('Icons')); ?></p>
                </a>
            </li>
             
            
            <li>
                <a href="<?php echo e(route('tables')); ?>">
                    <i class="tim-icons icon-puzzle-10"></i>
                    <p><?php echo e(__('Tables')); ?></p>
                </a>
            </li>
            <li>
                <a href="<?php echo e(route('payments')); ?>">
                    <i class="tim-icons icon-align-center"></i>
                    <p><?php echo e(__('Money Distrution')); ?></p>
                </a>
            </li>
        </ul>
    </div>
</div>
<?php /**PATH /home/code-lord/Desktop/web_interface/resources/views/layouts/navbars/sidebar.blade.php ENDPATH**/ ?>