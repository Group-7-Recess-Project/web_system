<?php $__env->startSection('content'); ?>
<div class="row">
  <div class="col-md-12">
    <div class="card ">
      <div class="card-header">
        <h1 class="card-title"> Officers</h1>
      </div>
      <div class="card-body">
        <div class="table">
          <table class="table tablesorter table-stripped" id="">
            <thead class=" text-primary">
              <tr>
                <th>
                  Name
                </th>
                <th>
                  Category
                </th>
                <th>
                  Hospital
                </th>
                <th class="text-center">
                  Salary
                </th>
              </tr>
            </thead>
            <tbody>
               <?php $__currentLoopData = $officers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $officer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


              <tr>
                <td>
                  <?php echo e($officer['officer_name']); ?>

                </td>
                <td>
                  <?php echo e($officer['job_role']); ?>

                </td>
                <td>
                    <?php echo e($officer['hospital_name']); ?>

                </td>
                <td class="text-center">
                  <?php echo e($officer['salary']); ?>

                </td>
              </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
  
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', ['page' => __('Tables'), 'pageSlug' => 'tables'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/code-lord/Desktop/web_interface/resources/views/tables/officers.blade.php ENDPATH**/ ?>