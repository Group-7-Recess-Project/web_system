<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header">
        <h1 class="title"><?php echo e(__('Register Donnation')); ?></h1>
    </div>
    <form method="post" action="<?php echo e(route('registerDonation')); ?>" autocomplete="off">
        <div class="card-body">
            <?php echo csrf_field(); ?>

            <?php echo $__env->make('alerts.success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="form-group">
                <label><?php echo e(__('Donor Name')); ?></label>
                <input type="text" name="donor_name" class="form-control" placeholder="<?php echo e(__('Name of Donor')); ?>" value="" required>

            </div>

            <div class="form-group">
                <label><?php echo e(__('Amount(UGX)')); ?></label>
                <input type="text" name="amount" class="form-control" placeholder="<?php echo e(__('UGX 1000000')); ?>" value="" required>

            </div>
            <div class="form-group">
                <label><?php echo e(__('Date')); ?></label>
                <input type="date" name="date" class="form-control" placeholder="<?php echo e(__('Select')); ?>" value="" required>
            </div>
        </div>
        <div class="card-footer">
            <button type="submit" class="btn btn-fill btn-primary"><?php echo e(__('Register')); ?></button>
        </div>
    </form>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', ['pageSlug' => 'dashboard'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/code-lord/Desktop/web_interface/resources/views/register/donation.blade.php ENDPATH**/ ?>