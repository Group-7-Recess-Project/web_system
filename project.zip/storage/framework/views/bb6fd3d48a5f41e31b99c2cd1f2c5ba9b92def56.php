<style>
    .fix-it{
        position:sticky !important;
        top:0 !important;
        z-index: 100 !important;
        background-color: #525f7f  !important;

    }
    nav.navbar.navbar-expand-lg.navbar-absolute.navbar-transparent{
        background: #525f7f !important;
    }
    </style>
<div class="fix-it">
    <nav class="navbar navbar-expand-lg navbar-absolute navbar-transparent">
        <div class="container-fluid">
            <div class="navbar-wrapper d-none">
                <div class="navbar-toggle d-inline">
                    <button type="button" class="navbar-toggler">
                        <span class="navbar-toggler-bar bar1"></span>
                        <span class="navbar-toggler-bar bar2"></span>
                        <span class="navbar-toggler-bar bar3"></span>
                    </button>
                </div>
                <a class="navbar-brand" href="#"><?php echo e($page ?? __('Dashboard')); ?></a>
            </div>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navigation" aria-expanded="false" aria-label="<?php echo e(__('Toggle navigation')); ?>">
                <span class="navbar-toggler-bar navbar-kebab"></span>
                <span class="navbar-toggler-bar navbar-kebab"></span>
                <span class="navbar-toggler-bar navbar-kebab"></span>
            </button>
            <div class="collapse navbar-collapse" id="navigation">
                <div class="mr-auto text-primary">
                   <h1 style="margin:0; color: white;">COVID 19 CASE MANAGEMENT SYSTEM</h1>
                </div>
                <ul class="navbar-nav ml-auto">
                    
                        
                            
                        
                    
                    <li class="dropdown nav-item">
                        <a href="#" class="dropdown-toggle nav-link" data-toggle="dropdown">
                            Notifications
                            <i class="tim-icons icon-bell-55" ><sup style="color: white;">4</sup></i>
                            <p class="d-lg-none"> <?php echo e(__('Notifications')); ?> </p>
                        </a>
                        <ul class="dropdown-menu dropdown-menu-right dropdown-navbar">
                            <li class="nav-link">
                                <a href="#" class="nav-item dropdown-item"><?php echo e(__('Mike John responded to your email')); ?></a>
                            </li>
                            <li class="nav-link">
                                <a href="#" class="nav-item dropdown-item"><?php echo e(__('You have 5 more tasks')); ?></a>
                            </li>
                            <li class="nav-link">
                                <a href="#" class="nav-item dropdown-item"><?php echo e(__('Your friend Michael is in town')); ?></a>
                            </li>
                            <li class="nav-link">
                                <a href="#" class="nav-item dropdown-item"><?php echo e(__('Another notification')); ?></a>
                            </li>
                            <li class="nav-link">
                                <a href="#" class="nav-item dropdown-item"><?php echo e(__('Another one')); ?></a>
                            </li>
                        </ul>
                    </li>
                    <li class="dropdown nav-item">
                        <a href="#" class="dropdown-toggle nav-link" data-toggle="dropdown">
                            <div class="photo">
                                <img src="<?php echo e(asset('black')); ?>/img/anime3.png" alt="<?php echo e(__('Profile Photo')); ?>">
                            </div>
                            <b class="caret d-none d-lg-block d-xl-block"></b>
                            <p class="d-lg-none"><?php echo e(__('Log out')); ?></p>
                        </a>
                        <ul class="dropdown-menu dropdown-navbar">
                            <li class="nav-link">
                                <a href="<?php echo e(route('profile.edit')); ?>" class="nav-item dropdown-item"><?php echo e(__('Profile')); ?></a>
                            </li>
                            
                            <li class="dropdown-divider"></li>
                            <li class="nav-link">
                                <a href="<?php echo e(route('logout')); ?>" class="nav-item dropdown-item" onclick="event.preventDefault();  document.getElementById('logout-form').submit();"><?php echo e(__('Log out')); ?></a>
                            </li>
                        </ul>
                    </li>
                    <li class="separator d-lg-none"></li>
                </ul>
            </div>
        </div>
    </nav>
    <div class="modal modal-search fade" id="searchModal" tabindex="-1" role="dialog" aria-labelledby="searchModal" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <input type="text" class="form-control" id="inlineFormInputGroup" placeholder="<?php echo e(__('SEARCH')); ?>">
                    <button type="button" class="close" data-dismiss="modal" aria-label="<?php echo e(__('Close')); ?>">
                        <i class="tim-icons icon-simple-remove"></i>
                  </button>
                </div>
            </div>
        </div>
    </div>

</div>
<?php /**PATH /home/code-lord/Desktop/web_interface/resources/views/layouts/navbars/navs/auth.blade.php ENDPATH**/ ?>