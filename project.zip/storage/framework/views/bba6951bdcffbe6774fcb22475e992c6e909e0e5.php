  
    <!-- Chart's container -->
    <?php $__env->startSection('content'); ?>
    <div id="chart" style="height: 200px; background: rgba(11, 223, 75, 0.212);"></div>
    <!-- Charting library -->
    <script src="https://unpkg.com/chart.js@2.9.3/dist/Chart.min.js"></script>
    <!-- Chartisan -->
    <script src="https://unpkg.com/@chartisan/chartjs@^2.1.0/dist/chartisan_chartjs.umd.js"></script>
    <!-- Your application script -->
    <script>
      const chart = new Chartisan({
        el: '#chart',
        url: "<?php echo route('charts.'.'donations'); ?>",
        hooks: new ChartisanHooks()
            .beginAtZero()
            .colors()
            .title("A graph of Donors Vs Amount")
            .responsive()
            .datasets([{type:"bar",
            backgroundColor: "blue",
            hoverBackgroundColor: "white",
            minBarLength:1,
            barPercentage: 0.8
        }])



      });

    </script>
    <?php $__env->stopSection(); ?>
  


<?php echo $__env->make('layouts.app', ['class' => 'login-page', 'contentClass' => 'login-page'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/code-lord/Desktop/pkproject/resources/views/charts/donations_months_chart.blade.php ENDPATH**/ ?>