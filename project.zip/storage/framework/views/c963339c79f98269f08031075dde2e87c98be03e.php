<?php if($errors->has($field)): ?>
    <span class="invalid-feedback" role="alert"><?php echo e($errors->first($field)); ?></span>
<?php endif; ?>
<?php /**PATH /home/code-lord/Desktop/G-7-Recess-Project/web_system/resources/views/alerts/feedback.blade.php ENDPATH**/ ?>