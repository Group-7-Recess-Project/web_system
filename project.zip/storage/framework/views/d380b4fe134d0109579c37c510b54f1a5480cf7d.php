<?php echo e($slot); ?>

<?php /**PATH /home/code-lord/Desktop/pkproject/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>