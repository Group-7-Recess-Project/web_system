<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>CoCaRS | Dashboard</title>
  </head>
  <body>
<h1>This is admin's Dashboard</h1>
<a href="patients">Here</a>
  </body>
</html>
<?php /**PATH /home/code-lord/Desktop/pkproject/resources/views/dashdoard.blade.php ENDPATH**/ ?>