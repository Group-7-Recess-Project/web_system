<style>
    img{

    }
</style>
<?php $__env->startSection('content'); ?>
    <div class="col-md-10 text-center ml-auto mr-auto">
        
    </div>
    <div class="col-lg-4 col-md-6 ml-auto mr-auto">
        <form class="form" method="post" action="<?php echo e(route('login')); ?>">
            <?php echo csrf_field(); ?>

            <div class="card card-login card-tranparent ">
                
                    
                    <h1 class="card-title text-center">Log in</h1>
                
                
                <div class="card-body mt-0 mb-0">
                    
                    <div class="text-white text-center"><h4 class="card-title text-center">Email</h4></div>
                    <div class="input-group mt-0<?php echo e($errors->has('email') ? ' has-danger' : ''); ?>">
                        
                        <input type="email" name="email" class="form-control p-4 <?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" placeholder="<?php echo e(__('Email')); ?>">
                        <?php echo $__env->make('alerts.feedback', ['field' => 'email'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                    <div class="text-white mt-5 text-center"> <h4 class="card-title text-center">Password</h4></div>
                    <div class="input-group mt-3 mb-0<?php echo e($errors->has('password') ? ' has-danger' : ''); ?>">
                        <input type="password" placeholder="<?php echo e(__('Password')); ?>" name="password" class="form-control p-4<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>">
                        <?php echo $__env->make('alerts.feedback', ['field' => 'password'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                </div>
                <div class="card-footer">
                    
                    <div class="text-center mt-0">
                        <h1>
                            <button type="submit" class="btn text-center" ><?php echo e(__('Log In')); ?></button>
                        </h1>
                    </div>
                    
                    <div class="pull-left">
                        <h6>
                            <a href="<?php echo e(route('register')); ?>" class="link footer-link"><?php echo e(__('Create Account')); ?></a>
                        </h6>
                    </div>
                    <div class="pull-right">
                        <h6>
                            <a href="<?php echo e(route('password.request')); ?>" class="link footer-link"><?php echo e(__('Forgot password?')); ?></a>
                        </h6>
                    </div>
                </div>
            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', ['class' => 'login-page', 'contentClass' => 'login-page'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/code-lord/Desktop/web_interface/resources/views/auth/login.blade.php ENDPATH**/ ?>