about.
<?php /**PATH D:\xampp\htdocs\pkproject\resources\views/pages/about.blade.php ENDPATH**/ ?>