<?php $__env->startSection('content'); ?>
<div class="row">
  <div class="col-md-12">
    <div class="card ">
      <div class="card-header">
        <h1 class="card-title">Hospitals <hr></h1>
      </div>
      <div class="card-body">
        <div class="table-responsiv\e">
          <table class="table tablesorter table-stripped" id="">
            <thead class=" text-primary">
              <tr>
                <th>
                  Hospital Name
                </th>
                <th>
                  category
                </th>
              </tr>
            </thead>
            <tbody>
               <?php $__currentLoopData = $hospitals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hospital): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


              <tr>
                <td>
                  <?php echo e($hospital['hospital_name']); ?>

                </td>
                <td>
                    <?php echo e($hospital['hospital_category']); ?>

                </td>
              </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>
          Back
        </div>
      </div>
    </div>
  </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', ['page' => __('Tables'), 'pageSlug' => 'tables'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/code-lord/Desktop/web_interface/resources/views/tables/hospitals.blade.php ENDPATH**/ ?>