<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-6">
      <div class="card ">
        <div class="card-header">
          <h1 class="card-title"> Patients</h1>
        </div>
        <div class="card-body">
          <div class="table">
            <table class="table tablesorter table-stripped" id="">
              <thead class=" text-primary">
                <tr>
                  <th>
                    Name
                  </th>
                  <th>
                    Category
                  </th>
                  <th>
                    Hospital
                  </th>
                  <th class="text-center">
                    Salary
                  </th>
                </tr>
              </thead>
              <tbody>
                 


                <tr>
                  <td>
                    
                  </td>
                  <td>
                    
                  </td>
                  <td>
                      
                  </td>
                  <td class="text-center">
                    
                  </td>
                </tr>
                
              </tbody>
            </table>
          </div>
          
            <i class="tim-icons icon-link-72"></i>
            <?php echo e(__('See More...')); ?>

        </a>
        </div>


      </div>

    </div>

    <div class="col-md-6">
        <div class="card ">
          <div class="card-header">
            <h1 class="card-title"> Donations</h1>
          </div>
          <div class="card-body">
            <div class="table">
              <table class="table tablesorter table-stripped" id="">
                <thead class=" text-primary">
                  <tr>
                    <th>
                      Name
                    </th>
                    <th>
                      Category
                    </th>
                    <th>
                      Hospital
                    </th>
                    <th class="text-center">
                      Salary
                    </th>
                  </tr>
                </thead>
                <tbody>
                   


                  <tr>
                    <td>
                      
                    </td>
                    <td>
                      
                    </td>
                    <td>
                        
                    </td>
                    <td class="text-center">
                      
                    </td>
                  </tr>
                  
                </tbody>
              </table>
            </div>
            
              <i class="tim-icons icon-link-72"></i>
              <?php echo e(__('See More...')); ?>

          </a>
          </div>


        </div>

      </div>


  </div>

  <div class="row">
    <div class="col-md-6">
      <div class="card ">
        <div class="card-header">
          <h1 class="card-title">Hospitals</h1>
        </div>
        <div class="card-body">
          <div class="table">
            <table class="table tablesorter table-stripped" id="">
              <thead class=" text-primary">
                <tr>
                  <th>
                    Name
                  </th>
                  <th>
                    Category
                  </th>
                  <th>
                    Hospital
                  </th>
                  <th class="text-center">
                    Salary
                  </th>
                </tr>
              </thead>
              <tbody>
                 


                <tr>
                  <td>
                    
                  </td>
                  <td>
                    
                  </td>
                  <td>
                      
                  </td>
                  <td class="text-center">
                    
                  </td>
                </tr>
                
              </tbody>
            </table>
          </div>
          <a href="<?php echo e(route('hospitals')); ?>">
            <i class="tim-icons icon-link-72"></i>
            <?php echo e(__('See More...')); ?>

        </a>
        </div>


      </div>

    </div>

    <div class="col-md-6">
        <div class="card ">
          <div class="card-header">
            <h1 class="card-title"> Officers</h1>
          </div>
          <div class="card-body">
            <div class="table">
              <table class="table tablesorter table-stripped" id="">
                <thead class=" text-primary">
                  <tr>
                    <th>
                      Name
                    </th>
                    <th>
                      Category
                    </th>
                    <th>
                      Hospital
                    </th>
                    <th class="text-center">
                      Salary
                    </th>
                  </tr>
                </thead>
                <tbody>
                   


                  <tr>
                    <td>
                      
                    </td>
                    <td>
                      
                    </td>
                    <td>
                        
                    </td>
                    <td class="text-center">
                      
                    </td>
                  </tr>
                  
                </tbody>
              </table>
            </div>
            <a href="<?php echo e(route('officers')); ?>">
              <i class="tim-icons icon-link-72"></i>
              <?php echo e(__('See More...')); ?>

          </a>
          </div>


        </div>

      </div>


  </div>

  <div class="row">
  <div class="col-md-12">
    <div class="card ">
      <div class="card-header">
        <h1 class="card-title"> Payments</h1>
      </div>
      <div class="card-body">
        <div class="table">
          <table class="table tablesorter table-stripped" id="">
            <thead class=" text-primary">
              <tr>
                <th>
                  Name
                </th>
                <th>
                  Category
                </th>
                <th>
                  Hospital
                </th>
                <th class="text-center">
                  Salary
                </th>
              </tr>
            </thead>
            <tbody>
               


              <tr>
                <td>
                  
                </td>
                <td>
                  
                </td>
                <td>
                    
                </td>
                <td class="text-center">
                  
                </td>
              </tr>
              
            </tbody>
          </table>
        </div>
        <a href="<?php echo e(route('officers')); ?>">
          <i class="tim-icons icon-link-72"></i>
          <?php echo e(__('See More...')); ?>

      </a>
      </div>


    </div>

  </div>


</div>



</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', ['page' => __('Tables'), 'pageSlug' => 'tables'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/code-lord/Desktop/G-7-Recess-Project/web_system/resources/views/pages/tables.blade.php ENDPATH**/ ?>