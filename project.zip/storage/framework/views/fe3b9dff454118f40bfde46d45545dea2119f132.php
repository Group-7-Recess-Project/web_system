<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-5 ml-auto">
            <div class="info-area info-horizontal mt-5">
                <div class="icon icon-warning">
                    <i class="tim-icons icon-wifi"></i>
                </div>
                <div class="description">
                    <h1 class="info-title"><?php echo e(__('Spread the Covid-19 Message')); ?></h1>
                    <p class="description">
                        <?php echo e(__('Observe the SOP\'s')); ?>

                    </p>
                </div>
            </div>
            <div class="info-area info-horizontal">
                <div class="icon icon-primary">
                    <i class="tim-icons icon-triangle-right-17"></i>
                </div>
                <div class="description">
                    <h3 class="info-title"><?php echo e(__('Fully Accessible From anywhere')); ?></h3>
                    <p class="description">
                        <?php echo e(__('This system is at your service 24/7. Access it from anywhere around the world.')); ?>

                    </p>
                </div>
            </div>
            <div class="info-area info-horizontal">
                <div class="icon icon-info">
                    <i class="tim-icons icon-trophy"></i>
                </div>
                <div class="description">
                    <h3 class="info-title"><?php echo e(__('Approved by WHO')); ?></h3>
                    <p class="description">
                        <?php echo e(__('Analyze everthing professionally')); ?>

                    </p>
                </div>
            </div>
        </div>
        <div class="col-md-5 mr-auto">
            <div class="card card-register card-transparent">
                <h1 class="card-title text-center">Register</h1>
                
                <form class="form" method="post" action="<?php echo e(route('register')); ?>">
                    <?php echo csrf_field(); ?>

                    <div class="card-body">
                        <h4 class="card-title text-center text-white">Full Name</h4>
                        <div class="input-group mt-1<?php echo e($errors->has('name') ? ' has-danger' : ''); ?>">
                            
                            <input type="text" name="name" class="form-control<?php echo e($errors->has('name') ? ' is-invalid' : ''); ?>" placeholder="<?php echo e(__('Name')); ?>">
                            <?php echo $__env->make('alerts.feedback', ['field' => 'name'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </div>
                        <h4 class="card-title text-center mt-4">Email</h4>
                        <div class="input-group mt-0<?php echo e($errors->has('email') ? ' has-danger' : ''); ?>">
                            
                            <input type="email" name="email" class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" placeholder="<?php echo e(__('Email')); ?>">
                            <?php echo $__env->make('alerts.feedback', ['field' => 'email'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </div>
                        <h4 class="card-title text-center mt-4">Choose Role</h4>
                        <div class="input-group mt-0">
                            
                            <select name="role" class="form-control">
                                <option value="admin">Administrator</option>
                                <option value="director">Director</option>
                            </select>
                        </div>
                        <h4 class="card-title text-center mt-4">Password</h4>
                        <div class="input-group mt-0<?php echo e($errors->has('password') ? ' has-danger' : ''); ?>">
                            
                            <input type="password" name="password" class="form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" placeholder="<?php echo e(__('Password')); ?>">
                            <?php echo $__env->make('alerts.feedback', ['field' => 'password'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </div>
                        <h4 class="card-title text-center mt-4">Confirm Password</h4>
                        <div class="input-group mt-0">
                            
                            <input type="password" name="password_confirmation" class="form-control" placeholder="<?php echo e(__('Confirm Password')); ?>">
                        </div>
                        <div class="form-check text-left">
                            <label class="form-check-label">
                                <input class="form-check-input" type="checkbox">
                                <span class="form-check-sign"></span>
                                <?php echo e(__('I agree to the')); ?>

                                <a href="#"><?php echo e(__('terms and conditions')); ?></a>.
                            </label>
                        </div>
                    </div>
                    <div class="card-footer d-flex flex-column">
                        <button type="submit" class="btn btn-primary btn-round btn-lg"><?php echo e(__('Register')); ?></button>
                    </div>
                </form>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', ['class' => 'register-page', 'contentClass' => 'register-page'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/code-lord/Desktop/web_interface/resources/views/auth/register.blade.php ENDPATH**/ ?>